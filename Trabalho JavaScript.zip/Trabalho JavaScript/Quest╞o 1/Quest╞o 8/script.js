document.querySelector('#calcular').addEventListener('click', function () {
  let nivel = parseInt(document.querySelector('#nivel').value);
  let horas = parseFloat(document.querySelector('#horas').value);

  let valorHora;

  if (nivel === 1) {
    valorHora = 12;
  } else if (nivel === 2) {
    valorHora = 17;
  } else if (nivel === 3) {
    valorHora = 25;
  } else {
    document.querySelector('#resultado').textContent = 'Nível inválido! Use 1, 2 ou 3.';
    return;
  }

  let salario = valorHora * horas * 4.5;

  document.querySelector('#resultado').textContent = `Salário do professor: R$ ${salario.toFixed(2)}`;
});
