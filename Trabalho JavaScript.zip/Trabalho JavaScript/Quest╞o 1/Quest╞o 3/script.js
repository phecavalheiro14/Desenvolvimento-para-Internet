let botao = document.querySelector("#calcular");

botao.addEventListener("click", () => {
  let ano = parseInt(document.querySelector("#ano").value);
  let valor = parseFloat(document.querySelector("#valor").value);
  let resultado = document.querySelector("#resultado");

  if (isNaN(ano) || isNaN(valor) || ano <= 0 || valor <= 0) {
    resultado.textContent = "Por favor, insira valores válidos.";
    return;
  }

  let taxa = 0;
  if (ano < 1990) {
    taxa = 0.01; // 1%
  } else {
    taxa = 0.015; // 1.5%
  }

  let imposto = valor * taxa;
  resultado.innerHTML = `O imposto a ser pago é <strong>R$${imposto.toFixed(2)}</strong>`;
});
