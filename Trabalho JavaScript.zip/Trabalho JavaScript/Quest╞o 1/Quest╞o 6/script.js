function calcularValor() {
  let codigo = parseInt(document.querySelector("#codigo").value);
  let quantidade = parseInt(document.querySelector("#quantidade").value);
  let resultado = document.querySelector("#resultado");

  if (isNaN(codigo) || isNaN(quantidade) || quantidade <= 0) {
    resultado.innerText = "Por favor, preencha os campos corretamente.";
    return;
  }

  let cardapio = {
    1: { nome: "Cachorro Quente", preco: 11.00 },
    2: { nome: "Bauru", preco: 8.50 },
    3: { nome: "Misto Quente", preco: 8.00 },
    4: { nome: "Hamburguer", preco: 9.00 },
    5: { nome: "Cheeseburger", preco: 10.00 },
    6: { nome: "Refrigerante", preco: 4.50 },
  };

  let item = cardapio[codigo];

  if (!item) {
    resultado.innerText = "Código inválido. Tente um de 1 a 6.";
    return;
  }

  let total = item.preco * quantidade;

  resultado.innerText = `Item: ${item.nome}\nQuantidade: ${quantidade}\nTotal a pagar: R$ ${total.toFixed(2)}`;
}
