function calcularCredito() {
  const inputSaldo = document.querySelector("#saldo");
  const divResultado = document.querySelector("#resultado");

  const saldo = parseFloat(inputSaldo.value);
  let percentual = 0;
  let credito = 0;

  if (isNaN(saldo) || saldo < 0) {
    divResultado.innerText = "Por favor, insira um valor válido.";
    return;
  }

  if (saldo >= 0 && saldo <= 200) {
    divResultado.innerText =
      `Saldo médio: R$ ${saldo.toFixed(2)}\nNenhum crédito disponível.`;
    return;
  } else if (saldo <= 400) {
    percentual = 0.2;
  } else if (saldo <= 600) {
    percentual = 0.3;
  } else {
    percentual = 0.4;
  }

  credito = saldo * percentual;

  divResultado.innerText =
    `Saldo médio: R$ ${saldo.toFixed(2)}\nCrédito concedido: R$ ${credito.toFixed(2)}`;
}
