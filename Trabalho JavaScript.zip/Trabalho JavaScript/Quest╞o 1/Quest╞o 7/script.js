function calcularVenda() {
  let preco = parseFloat(document.querySelector("#preco").value);
  let codigo = document.querySelector("#codigo").value.toLowerCase();
  let resultado = document.querySelector("#resultado");

  if (isNaN(preco) || preco <= 0 || !"abcd".includes(codigo)) {
    resultado.innerText = "Verifique os dados informados.";
    return;
  }

  let total;

  if (codigo === "a") {
    total = preco * 0.9;
    resultado.innerText = `Condição: Dinheiro/Cheque\nTotal com 10% de desconto: R$ ${total.toFixed(2)}`;
  } else if (codigo === "b") {
    total = preco * 0.85;
    resultado.innerText = `Condição: Cartão de crédito\nTotal com 15% de desconto: R$ ${total.toFixed(2)}`;
  } else if (codigo === "c") {
    total = preco;
    resultado.innerText = `Condição: 2x sem juros\nTotal a pagar: R$ ${total.toFixed(2)} (2x de R$ ${(total / 2).toFixed(2)})`;
  } else if (codigo === "d") {
    total = preco * 1.1;
    resultado.innerText = `Condição: 2x com juros (10%)\nTotal com juros: R$ ${total.toFixed(2)} (2x de R$ ${(total / 2).toFixed(2)})`;
  }
}
