function verificarTriangulo() {
  let x = parseFloat(document.querySelector('#ladonum1').value);
  let y = parseFloat(document.querySelector('#ladonum2').value);
  let z = parseFloat(document.querySelector('#ladonum3').value);
  let res = document.querySelector('#ValorFinal');

  if (isNaN(x) | isNaN(y) | isNaN(z)) {
    res.innerHTML = "Preencha com numeros os campos.";
    return;
  }

  if (x <= 0 | y <= 0 | z <= 0) {
    res.innerHTML = "Todos os lados devem ser positivos!.";
    return;
  }

  if (x < y + z && y < x + z && z < x + y) {
    if (x === y && y === z) {
      res.innerHTML = "Tri&acircngulo equil&aacutetero.";
    } else if (x === y || x === z || y === z) {
      res.innerHTML = "Tri&acircngulo is&oacutesceles.";
    } else {
      res.innerHTML = "Tri&acircngulo escaleno.";
    }
  } else {
    res.innerHTML = "N&atildeo formam um Tri&acircngulo.";
  }
}