let botao = document.querySelector("#calcular");

botao.onclick = function() {
  let salario = parseFloat(document.querySelector("#salario").value);
  let codigo = parseInt(document.querySelector("#codigo").value);
  let resultado = document.querySelector("#resultado");

  if (isNaN(salario) || isNaN(codigo) || salario <= 0) {
    resultado.textContent = "Por favor, insira valores válidos.";
    return;
  }

  let aumento = 0;
  let cargo = "";

  switch (codigo) {
    case 101:
      cargo = "Gerente";
      aumento = 0.10;
      break;
    case 102:
      cargo = "Engenheiro";
      aumento = 0.20;
      break;
    case 103:
      cargo = "Técnico";
      aumento = 0.30;
      break;
    default:
      cargo = "Cargo não listado";
      aumento = 0.40;
      break;
  }

  let novoSalario = salario + (salario * aumento);
  let diferenca = novoSalario - salario;

  resultado.innerHTML = `
    Cargo: <strong>${cargo}</strong><br>
    Salário Antigo: <strong>R$ ${salario.toFixed(2)}</strong><br>
    Novo Salário: <strong>R$ ${novoSalario.toFixed(2)}</strong><br>
    Diferença: <strong>R$ ${diferenca.toFixed(2)}</strong>
  `;
};
